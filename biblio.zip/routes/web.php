<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LivreController;
use App\Http\Controllers\AuteurController;

Route::get('/', function () {
    return view('layouts.app');
});


Route::resource('livres', LivreController::class);
Route::resource('auteurs', AuteurController::class);