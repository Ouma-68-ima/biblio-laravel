

<?php $__env->startSection('title', 'Livres'); ?>

<?php $__env->startSection('content'); ?>
<h2>Liste des livres</h2>

<a href="<?php echo e(route('livres.create')); ?>" class="btn btn-success mb-3">Ajouter livre</a>

<table class="table table-bordered">
<thead>
<tr>
    <th>Titre</th>
    <th>Auteur</th>
    <th>ISBN</th>
    <th>Prix</th>
    <th>Stock</th>
    <th>Disponibilité</th>
    <th>Actions</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $livres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($livre->titre); ?></td>
    <td><?php echo e($livre->auteur->nom ?? ''); ?> <?php echo e($livre->auteur->prenom ?? ''); ?></td>
    <td><?php echo e($livre->isbn); ?></td>
    <td><?php echo e($livre->prix); ?> DH</td>
    <td><?php echo e($livre->stock); ?></td>
    <td><?php echo e($livre->disponible ? 'Oui' : 'Non'); ?></td>
    <td>
        <a href="<?php echo e(route('livres.edit', $livre->id)); ?>" class="btn btn-sm btn-warning">Modifier</a>
        <form action="<?php echo e(route('livres.destroy', $livre->id)); ?>" method="POST" style="display:inline">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn btn-sm btn-danger" onclick="return confirm('Supprimer?')">Supprimer</button>
        </form>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<?php echo e($livres->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views\layouts\livres\index.blade.php ENDPATH**/ ?>