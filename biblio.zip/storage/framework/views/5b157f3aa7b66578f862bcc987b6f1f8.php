

<?php $__env->startSection('title', 'Ajouter un auteur'); ?>

<?php $__env->startSection('content'); ?>
<h2>Ajouter un Auteur</h2>

<form action="<?php echo e(route('auteurs.store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<div class="mb-2"><label>Nom *</label><input type="text" name="nom" class="form-control" required></div>
<div class="mb-2"><label>Prénom *</label><input type="text" name="prenom" class="form-control" required></div>
<div class="mb-2"><label>Email *</label><input type="email" name="email" class="form-control" required></div>
<div class="mb-2"><label>Nationalité</label><input type="text" name="nationalite" class="form-control"></div>
<div class="mb-2"><label>Date Naissance (nullable)</label><input type="date" name="date_naissance" class="form-control"></div>
<button class="btn btn-success">Enregistrer</button>
<a href="<?php echo e(route('auteurs.index')); ?>" class="btn btn-secondary">Retour</a>
</form>

<?php if($errors->any()): ?>
<div class="alert alert-danger mt-3">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($error); ?><br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views\layouts\auteurs\create.blade.php ENDPATH**/ ?>