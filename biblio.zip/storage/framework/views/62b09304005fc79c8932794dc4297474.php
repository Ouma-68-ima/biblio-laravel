

<?php $__env->startSection('title', 'Modifier un auteur'); ?>

<?php $__env->startSection('content'); ?>
<h2>Modifier Auteur: <?php echo e($auteur->nom); ?></h2>

<form action="<?php echo e(route('auteurs.update', $auteur->id)); ?>" method="POST">
<?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
<div class="mb-2"><label>Nom</label><input type="text" name="nom" value="<?php echo e($auteur->nom); ?>" class="form-control" required></div>
<div class="mb-2"><label>Prénom</label><input type="text" name="prenom" value="<?php echo e($auteur->prenom); ?>" class="form-control" required></div>
<div class="mb-2"><label>Email</label><input type="email" name="email" value="<?php echo e($auteur->email); ?>" class="form-control" required></div>
<div class="mb-2"><label>Nationalité</label><input type="text" name="nationalite" value="<?php echo e($auteur->nationalite); ?>" class="form-control"></div>
<div class="mb-2"><label>Date Naissance</label><input type="date" name="date_naissance" value="<?php echo e($auteur->date_naissance); ?>" class="form-control"></div>
<button class="btn btn-warning">Modifier</button>
<a href="<?php echo e(route('auteurs.index')); ?>" class="btn btn-secondary">Retour</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views\layouts\auteurs\edit.blade.php ENDPATH**/ ?>