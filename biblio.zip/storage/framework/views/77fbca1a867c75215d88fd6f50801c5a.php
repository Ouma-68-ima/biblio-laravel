

<?php $__env->startSection('title', 'Auteurs'); ?>

<?php $__env->startSection('content'); ?>
<h2>Liste des Auteurs</h2>

<a href="<?php echo e(route('auteurs.create')); ?>" class="btn btn-success mb-3">Ajouter Auteur</a>
<a href="<?php echo e(route('livres.index')); ?>" class="btn btn-primary mb-3">Voir Livres</a>

<table class="table table-bordered">
<thead>
<tr>
    <th>ID</th>
    <th>Nom</th>
    <th>Prénom</th>
    <th>Email</th>
    <th>Nationalité</th>
    <th>Date Naissance</th>
    <th>Nombre Livres</th>
    <th>Actions</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $auteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($auteur->id); ?></td>
    <td><?php echo e($auteur->nom); ?></td>
    <td><?php echo e($auteur->prenom); ?></td>
    <td><?php echo e($auteur->email); ?></td>
    <td><?php echo e($auteur->nationalite); ?></td>
    <td><?php echo e($auteur->date_naissance ?? 'Non défini'); ?></td>
    <td><?php echo e($auteur->livres->count() ?? 0); ?></td>
    <td>
        <a href="<?php echo e(route('auteurs.show', $auteur->id)); ?>" class="btn btn-sm btn-info">Voir</a>
        <a href="<?php echo e(route('auteurs.edit', $auteur->id)); ?>" class="btn btn-sm btn-warning">Modifier</a>
        <form action="<?php echo e(route('auteurs.destroy', $auteur->id)); ?>" method="POST" style="display:inline">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn btn-sm btn-danger" onclick="return confirm('Supprimer auteur et ses livres?')">Supprimer</button>
        </form>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<?php echo e($auteurs->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views/layouts/auteurs/index.blade.php ENDPATH**/ ?>