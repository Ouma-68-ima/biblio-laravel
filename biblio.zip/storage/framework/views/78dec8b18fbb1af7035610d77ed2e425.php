

<?php $__env->startSection('title', $livre->titre); ?>

<?php $__env->startSection('content'); ?>
<h2><?php echo e($livre->titre); ?></h2>
<p><b>Auteur:</b> <?php echo e($livre->auteur->nom); ?> <?php echo e($livre->auteur->prenom); ?></p>
<p><b>ISBN:</b> <?php echo e($livre->isbn); ?></p>
<p><b>Prix:</b> <?php echo e($livre->prix); ?></p>
<p><b>Stock:</b> <?php echo e($livre->stock); ?></p>
<a href="<?php echo e(route('livres.index')); ?>" class="btn btn-secondary">Retour</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views\layouts\livres\show.blade.php ENDPATH**/ ?>