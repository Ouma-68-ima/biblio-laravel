

<?php $__env->startSection('title', 'Modifier un livre'); ?>

<?php $__env->startSection('content'); ?>
<h2>Modifier Livre: <?php echo e($livre->titre); ?></h2>

<form action="<?php echo e(route('livres.update', $livre->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<div class="mb-2">
<label>Titre *</label>
<input type="text" name="titre" value="<?php echo e(old('titre', $livre->titre)); ?>" class="form-control" required>
</div>

<div class="mb-2">
<label>ISBN *</label>
<input type="text" name="isbn" value="<?php echo e(old('isbn', $livre->isbn)); ?>" class="form-control" required>
</div>

<div class="mb-2">
<label>Prix *</label>
<input type="number" step="0.01" name="prix" value="<?php echo e(old('prix', $livre->prix)); ?>" class="form-control" required>
</div>

<div class="mb-2">
<label>Stock *</label>
<input type="number" name="stock" value="<?php echo e(old('stock', $livre->stock)); ?>" class="form-control" required>
</div>

<div class="mb-2">
<label>Date Publication</label>
<input type="date" name="date_publication" value="<?php echo e(old('date_publication', $livre->date_publication)); ?>" class="form-control">
</div>

<div class="mb-2">
<label>Auteur *</label>
<select name="auteurs_id" class="form-control" required>
    <?php $__currentLoopData = $auteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($auteur->id); ?>" <?php echo e($livre->auteurs_id == $auteur->id ? 'selected' : ''); ?>>
        <?php echo e($auteur->nom); ?> <?php echo e($auteur->prenom); ?>

    </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

<div class="mb-2">
<label>Disponible</label>
<select name="disponible" class="form-control">
    <option value="1" <?php echo e($livre->disponible == 1 ? 'selected' : ''); ?>>Oui</option>
    <option value="0" <?php echo e($livre->disponible == 0 ? 'selected' : ''); ?>>Non</option>
</select>
</div>

<button class="btn btn-warning">Modifier</button>
<a href="<?php echo e(route('livres.index')); ?>" class="btn btn-secondary">Retour</a>
</form>

<?php if($errors->any()): ?>
<div class="alert alert-danger mt-3">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($error); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views\layouts\livres\edit.blade.php ENDPATH**/ ?>