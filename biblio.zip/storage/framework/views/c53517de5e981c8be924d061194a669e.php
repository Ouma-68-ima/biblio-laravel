

<?php $__env->startSection('title', 'Ajouter un livre'); ?>

<?php $__env->startSection('content'); ?>
<h2>Ajouter un livre</h2>

<form action="<?php echo e(route('livres.store')); ?>" method="POST">
<?php echo csrf_field(); ?>
<div class="mb-2"><label>Titre</label><input type="text" name="titre" class="form-control" required></div>
<div class="mb-2"><label>ISBN</label><input type="text" name="isbn" class="form-control" required></div>
<div class="mb-2"><label>Prix</label><input type="number" step="0.01" name="prix" class="form-control" required></div>
<div class="mb-2"><label>Stock</label><input type="number" name="stock" class="form-control" required></div>
<div class="mb-2"><label>Date Publication</label><input type="date" name="date_publication" class="form-control"></div>
<div class="mb-2">
    <label>Auteur - Liste déroulante</label>
    <select name="auteurs_id" class="form-control" required>
        <option value="">-- Choisir auteur --</option>
        <?php $__currentLoopData = $auteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($auteur->id); ?>"><?php echo e($auteur->nom); ?> <?php echo e($auteur->prenom); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="mb-2"><label>Disponible</label>
<select name="disponible" class="form-control"><option value="1">Oui</option><option value="0">Non</option></select>
</div>
<button class="btn btn-success">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views\layouts\livres\create.blade.php ENDPATH**/ ?>