

<?php $__env->startSection('title', $auteur->nom . ' ' . $auteur->prenom); ?>

<?php $__env->startSection('content'); ?>
<h2><?php echo e($auteur->nom); ?> <?php echo e($auteur->prenom); ?></h2>
<p><b>Email:</b> <?php echo e($auteur->email); ?></p>
<p><b>Nationalité:</b> <?php echo e($auteur->nationalite); ?></p>
<p><b>Date Naissance:</b> <?php echo e($auteur->date_naissance ?? 'Non défini'); ?></p>

<h4 class="mt-4">Ses Livres (<?php echo e($auteur->livres->count()); ?>)</h4>
<ul class="list-group">
<?php $__empty_1 = true; $__currentLoopData = $auteur->livres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<li class="list-group-item"><?php echo e($livre->titre); ?> - <?php echo e($livre->prix); ?> DH - Stock: <?php echo e($livre->stock); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<li class="list-group-item">Aucun livre pour cet auteur</li>
<?php endif; ?>
</ul>

<a href="<?php echo e(route('auteurs.index')); ?>" class="btn btn-secondary mt-3">Retour</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp\www\gest_auteurs\resources\views\layouts\auteurs\show.blade.php ENDPATH**/ ?>